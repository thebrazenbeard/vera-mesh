# VeraRelay 0.4.0 Task 4 SQLite local evidence

Status: `LOCAL_GREEN / SOURCE_UNPINNED`
Branch: `work/vera-relay-0.4.0`
Git HEAD: none; repository still has no commits.
Git author identity: no local or global `user.name` / `user.email` configured.
Remote: none configured.

Fresh implementation coverage:
- SQLite opens in WAL mode with `synchronous=FULL` and foreign keys enabled.
- schema migration is transactional and a failed migration does not return writable service.
- pairing redemption atomically binds principal, signing key, HPKE key, scopes, token consumption, and audit append.
- message acceptance atomically binds nonce consumption, immutable message insert/idempotency, and audit append.
- minimum mutable state now includes relay installation identity, principals/keys/scopes, pairing sessions, nonces, messages, receipts, audit events, external audit checkpoints, and schema metadata.
- relay installation identity is singleton state; external audit checkpoints are append-only rows.

Fresh test result: `npm test` => **31/31 PASS**.
Task-4-focused result: `node --test tests/db.test.js tests/migrations.test.js` => **7/7 PASS**.

Predecessor `VeraRelay-0.3.0-0005-armada38x.spk` SHA-256 remains:
`58ee94b3f2ba99e8e0db835e22d5432a093e9852c6910f213cf5acc0188d00a0`

This evidence does not claim SOURCE-pinned status, build qualification, deployment, or runtime activation.