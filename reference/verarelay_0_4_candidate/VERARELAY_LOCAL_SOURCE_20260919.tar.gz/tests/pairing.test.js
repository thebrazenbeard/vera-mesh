'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { createPairingToken, enrollDevice, canonicalPairingProof } = require('../src/pairing');

function phone() {
  const {publicKey,privateKey}=crypto.generateKeyPairSync('ec',{namedCurve:'prime256v1'});
  const spki=publicKey.export({type:'spki',format:'der'});
  const deviceId=crypto.createHash('sha256').update(spki).digest('base64url');
  return {privateKey,deviceId,spki:spki.toString('base64url')};
}
function temp() { return fs.mkdtempSync(path.join(os.tmpdir(),'vera-pair-')); }

test('one-time pairing enrolls existing Android-style P-256 identity', () => {
  const varDir=temp(), p=phone();
  const pairing=createPairingToken(varDir, Date.parse('2026-09-12T18:00:00Z'));
  const nonce='pair-nonce';
  const proof=canonicalPairingProof({deviceId:p.deviceId,nonce,token:pairing.token});
  const proofSignature=crypto.sign('sha256',Buffer.from(proof),p.privateKey).toString('base64url');
  const result=enrollDevice({varDir,token:pairing.token,deviceId:p.deviceId,publicKeySpkiBase64Url:p.spki,proofSignature,nonce,now:Date.parse('2026-09-12T18:01:00Z')});
  assert.equal(result.status,'active');
  assert.ok(fs.existsSync(path.join(varDir,'devices',`${p.deviceId}.json`)));
  assert.throws(()=>enrollDevice({varDir,token:pairing.token,deviceId:p.deviceId,publicKeySpkiBase64Url:p.spki,proofSignature,nonce,now:Date.parse('2026-09-12T18:01:01Z')}),/pairing_not_enabled/);
});

test('pairing rejects device id not derived from supplied public key', () => {
  const varDir=temp(), p=phone(); const pairing=createPairingToken(varDir);
  assert.throws(()=>enrollDevice({varDir,token:pairing.token,deviceId:'wrong-device',publicKeySpkiBase64Url:p.spki,proofSignature:'bad',nonce:'n'}),/device_identity_mismatch/);
});