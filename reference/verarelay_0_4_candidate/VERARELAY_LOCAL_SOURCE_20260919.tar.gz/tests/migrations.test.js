'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { openRelayDatabase } = require('../src/db');

function dbPath() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-migrate-'));
  return path.join(dir, 'relay.sqlite3');
}

test('failed migration never returns writable service', () => {
  const pathName = dbPath();
  const migrations = [
    { version:1, up(db){ db.exec('CREATE TABLE sentinel(id INTEGER PRIMARY KEY)'); } },
    { version:2, up(db){ db.exec('CREATE TABLE partial(id INTEGER PRIMARY KEY)'); throw new Error('boom'); } }
  ];
  assert.throws(() => openRelayDatabase({ dbPath:pathName, migrations }), /migration_failed.*boom/);
  const { DatabaseSync } = require('node:sqlite');
  const db = new DatabaseSync(pathName, { readOnly:true });
  const names = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r=>r.name);
  assert.ok(names.includes('sentinel'));
  assert.ok(!names.includes('partial'));
  db.close();
});