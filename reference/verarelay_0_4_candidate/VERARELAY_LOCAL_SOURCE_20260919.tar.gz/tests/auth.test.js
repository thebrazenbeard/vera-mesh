'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { canonicalRequest, verifySignedRequest } = require('../src/auth');

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-auth-'));
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve:'prime256v1' });
  const spki = publicKey.export({ type:'spki', format:'der' });
  const deviceId = crypto.createHash('sha256').update(spki).digest('base64url');
  const device = { deviceId, status:'active', algorithm:'ES256', publicKeySpkiBase64Url:spki.toString('base64url') };
  fs.mkdirSync(path.join(dir, 'devices'), { recursive:true });
  fs.writeFileSync(path.join(dir, 'devices', `${deviceId}.json`), JSON.stringify(device));
  return { dir, privateKey, deviceId };
}

function signed(privateKey, sequence=1, nonce='nonce-1', timestamp='2026-09-12T18:00:00.000Z') {
  const req = { method:'POST', path:'/v1/queue/phone-to-host', timestamp, nonce, sequence,
    bodyHash:crypto.createHash('sha256').update('{}').digest('hex') };
  const signature = crypto.sign('sha256', Buffer.from(canonicalRequest(req)), privateKey).toString('base64url');
  return { req, signature };
}

test('accepts Android-compatible ES256 request and persists state', () => {
  const f = fixture(); const s = signed(f.privateKey);
  const result = verifySignedRequest({ varDir:f.dir, request:s.req,
    headers:{deviceId:f.deviceId, signature:s.signature}, now:Date.parse('2026-09-12T18:00:01Z') });
  assert.equal(result.deviceId, f.deviceId);
  assert.equal(result.signatureVerified, true);
});
test('rejects replayed nonce', () => {
  const f = fixture(); const s = signed(f.privateKey);
  const headers = {deviceId:f.deviceId, signature:s.signature};
  verifySignedRequest({ varDir:f.dir, request:s.req, headers, now:Date.parse('2026-09-12T18:00:01Z') });
  assert.throws(() => verifySignedRequest({ varDir:f.dir, request:s.req, headers, now:Date.parse('2026-09-12T18:00:02Z') }), /replay_detected/);
});

test('rejects non-monotonic sequence with fresh nonce', () => {
  const f = fixture(); const first = signed(f.privateKey, 5, 'n5');
  verifySignedRequest({ varDir:f.dir, request:first.req,
    headers:{deviceId:f.deviceId,signature:first.signature}, now:Date.parse('2026-09-12T18:00:01Z') });
  const stale = signed(f.privateKey, 5, 'n6');
  assert.throws(() => verifySignedRequest({ varDir:f.dir, request:stale.req,
    headers:{deviceId:f.deviceId,signature:stale.signature}, now:Date.parse('2026-09-12T18:00:02Z') }), /sequence_not_monotonic/);
});

test('rejects revoked device even with valid signature', () => {
  const f = fixture();
  const file = path.join(f.dir, 'devices', `${f.deviceId}.json`);
  const record = JSON.parse(fs.readFileSync(file, 'utf8'));
  record.status = 'revoked'; fs.writeFileSync(file, JSON.stringify(record));
  const s = signed(f.privateKey);
  assert.throws(() => verifySignedRequest({ varDir:f.dir, request:s.req,
    headers:{deviceId:f.deviceId,signature:s.signature}, now:Date.parse('2026-09-12T18:00:01Z') }), /device_revoked/);
});

test('rejects stale timestamp', () => {
  const f = fixture(); const s = signed(f.privateKey, 1, 'old', '2026-09-12T17:00:00.000Z');
  assert.throws(() => verifySignedRequest({ varDir:f.dir, request:s.req,
    headers:{deviceId:f.deviceId,signature:s.signature}, now:Date.parse('2026-09-12T18:00:01Z') }), /clock_skew/);
});