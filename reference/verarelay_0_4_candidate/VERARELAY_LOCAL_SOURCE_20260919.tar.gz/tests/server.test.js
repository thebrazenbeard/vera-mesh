'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const { canonicalRequest } = require('../src/auth');
const { createRelayServer } = require('../src/server');

function setup() {
  const varDir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-http-'));
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', {namedCurve:'prime256v1'});
  const spki = publicKey.export({type:'spki',format:'der'});
  const deviceId = crypto.createHash('sha256').update(spki).digest('base64url');
  fs.mkdirSync(path.join(varDir,'devices'),{recursive:true});
  fs.writeFileSync(path.join(varDir,'devices',`${deviceId}.json`),JSON.stringify({deviceId,status:'active',algorithm:'ES256',publicKeySpkiBase64Url:spki.toString('base64url')}));
  return {varDir,privateKey,deviceId};
}
function signedHeaders(f, method, requestPath, body, sequence, nonce) {
  const timestamp = new Date().toISOString();
  const bodyHash = crypto.createHash('sha256').update(body).digest('hex');
  const canon = canonicalRequest({method,path:requestPath,timestamp,nonce,sequence,bodyHash});
  return {
    'x-vera-device-id':f.deviceId,'x-vera-timestamp':timestamp,'x-vera-nonce':nonce,
    'x-vera-sequence':String(sequence),'x-vera-signature':crypto.sign('sha256',Buffer.from(canon),f.privateKey).toString('base64url'),
    'content-type':'application/json','content-length':Buffer.byteLength(body)
  };
}
function request(port, method, requestPath, headers={}, body='') {
  return new Promise((resolve,reject)=>{ const req=http.request({host:'127.0.0.1',port,method,path:requestPath,headers},res=>{
    const chunks=[]; res.on('data',d=>chunks.push(d)); res.on('end',()=>resolve({status:res.statusCode,body:JSON.parse(Buffer.concat(chunks).toString()||'{}')}));
  }); req.on('error',reject); if(body) req.write(body); req.end(); });
}
test('queue endpoints require Vera application authentication', async () => {
  const f=setup(); const server=createRelayServer({varDir:f.varDir,version:'0.3.0'});
  await new Promise(r=>server.listen(0,'127.0.0.1',r)); const port=server.address().port;
  try { const res=await request(port,'GET','/v1/queue/phone-to-host'); assert.equal(res.status,401); }
  finally { await new Promise(r=>server.close(r)); }
});

test('signed phone request can enqueue and fetch through localhost relay', async () => {
  const f=setup(); const server=createRelayServer({varDir:f.varDir,version:'0.3.0'});
  await new Promise(r=>server.listen(0,'127.0.0.1',r)); const port=server.address().port;
  try {
    const body=JSON.stringify({messageId:'m1',ciphertext:'cipher',sequenceNumber:1});
    const p='/v1/queue/phone-to-host';
    const post=await request(port,'POST',p,signedHeaders(f,'POST',p,body,1,'n1'),body);
    assert.equal(post.status,202);
    const getHeaders=signedHeaders(f,'GET',p,'',2,'n2'); delete getHeaders['content-length'];
    const got=await request(port,'GET',p,getHeaders);
    assert.equal(got.status,200); assert.equal(got.body.messages[0].messageId,'m1');
  } finally { await new Promise(r=>server.close(r)); }
});

test('health exposes no public-listener claim and VeraMesh role', async () => {
  const f=setup(); const server=createRelayServer({varDir:f.varDir,version:'0.3.0'});
  await new Promise(r=>server.listen(0,'127.0.0.1',r)); const port=server.address().port;
  try { const res=await request(port,'GET','/health'); assert.equal(res.status,200); assert.equal(res.body.publicListener,false); assert.equal(res.body.protocolDomain,'VeraMesh'); }
  finally { await new Promise(r=>server.close(r)); }
});
test('pairing endpoint enrolls an Android Keystore-compatible identity with one-time token', async () => {
  const f=setup();
  const {createPairingToken,canonicalPairingProof}=require('../src/pairing');
  const pairing=createPairingToken(f.varDir);
  const publicKey=crypto.createPublicKey(f.privateKey);
  const spki=publicKey.export({type:'spki',format:'der'}).toString('base64url');
  fs.unlinkSync(path.join(f.varDir,'devices',`${f.deviceId}.json`));
  const nonce='enroll-nonce';
  const proof=canonicalPairingProof({deviceId:f.deviceId,nonce,token:pairing.token});
  const proofSignature=crypto.sign('sha256',Buffer.from(proof),f.privateKey).toString('base64url');
  const body=JSON.stringify({token:pairing.token,deviceId:f.deviceId,publicKeySpkiBase64Url:spki,proofSignature,nonce});
  const server=createRelayServer({varDir:f.varDir,version:'0.3.0-0005'});
  await new Promise(r=>server.listen(0,'127.0.0.1',r)); const port=server.address().port;
  try{
    const res=await request(port,'POST','/v1/pair',{'content-type':'application/json','content-length':Buffer.byteLength(body)},body);
    assert.equal(res.status,201); assert.equal(res.body.deviceId,f.deviceId); assert.equal(res.body.status,'active');
    assert.equal(fs.existsSync(path.join(f.varDir,'state','pairing.json')),false);
  }finally{await new Promise(r=>server.close(r));}
});
test('health accepts an intact audit chain spanning legacy rotated segments', async () => {
  const f=setup();
  const {AuditLog}=require('../src/audit');
  const audit=new AuditLog(f.varDir);
  audit.append('legacy_before_rotation',{relayInstanceId:'legacy-relay'});
  const auditDir=path.join(f.varDir,'audit');
  fs.renameSync(path.join(auditDir,'audit.jsonl'),path.join(auditDir,'audit-1000.jsonl'));
  audit.append('current_after_rotation',{relayInstanceId:'legacy-relay'});
  const server=createRelayServer({varDir:f.varDir,version:'0.3.0-0005'});
  await new Promise(r=>server.listen(0,'127.0.0.1',r)); const port=server.address().port;
  try {
    const res=await request(port,'GET','/health');
    assert.equal(res.status,200); assert.equal(res.body.status,'ok');
    assert.equal(res.body.audit.ok,true); assert.equal(res.body.audit.records,2);
  } finally { await new Promise(r=>server.close(r)); }
});
