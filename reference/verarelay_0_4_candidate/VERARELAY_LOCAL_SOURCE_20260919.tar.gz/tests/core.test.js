'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { RelayCore } = require('../src/relay-core');

function core() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-core-'));
  return new RelayCore({ varDir:dir, version:'0.3.0' });
}

test('advertises VeraMesh-compatible capabilities without transport coupling', () => {
  const c = core(); const cap = c.capabilities();
  assert.equal(cap.nodeRole, 'relay');
  assert.equal(cap.protocolDomain, 'VeraMesh');
  assert.equal(cap.transportNeutral, true);
  assert.equal(cap.version, '0.3.0');
  assert.equal(cap.applicationAuthentication, 'ES256');
  assert.ok(!JSON.stringify(cap).includes('Tailscale'));
});

test('enqueue fetch acknowledge persists durable queue state', () => {
  const c = core();
  c.enqueue('phone-to-host', { messageId:'m1', ciphertext:'abc', sequenceNumber:1 }, 'patrick-phone');
  assert.equal(c.fetch('phone-to-host', -1, 10).length, 1);
  const ack = c.acknowledge('phone-to-host', 'm1', 'recipient_processed', 'vera-host');
  assert.equal(ack.acknowledgementState, 'recipient_processed');
  const c2 = new RelayCore({ varDir:c.varDir, version:'0.3.0' });
  assert.equal(c2.fetch('phone-to-host', -1, 10)[0].acknowledgementState, 'recipient_processed');
});

test('health is fail-closed and reports localhost security boundary', () => {
  const c = core(); const h = c.health();
  assert.equal(h.bindAddress, '127.0.0.1');
  assert.equal(h.publicListener, false);
  assert.equal(h.applicationAuthentication, 'ES256');
  assert.equal(h.status, 'ok');
});
test('queue limits fail closed before accepting excess messages', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-core-'));
  const c = new RelayCore({ varDir:dir, version:'0.3.0', maxMessagesPerQueue:1, maxQueueBytes:1024 });
  c.enqueue('phone-to-host', { messageId:'m1', ciphertext:'abc', sequenceNumber:1 }, 'patrick-phone');
  assert.throws(() => c.enqueue('phone-to-host', { messageId:'m2', ciphertext:'def', sequenceNumber:2 }, 'patrick-phone'), /queue_full/);
});

test('cleanup releases expired queue records', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-core-'));
  const c = new RelayCore({ varDir:dir, version:'0.3.0', messageRetentionHours:1 });
  const now = Date.parse('2026-09-12T18:00:00Z');
  c.enqueue('phone-to-host', { messageId:'m1', ciphertext:'abc', sequenceNumber:1 }, 'patrick-phone', now);
  assert.equal(c.fetch('phone-to-host', -1, 10).length, 1);
  c.cleanup(now + 2*60*60*1000);
  assert.equal(c.fetch('phone-to-host', -1, 10).length, 0);
});
test('health fails closed when audit integrity is broken', () => {
  const c=core();
  c.enqueue('phone-to-host',{messageId:'m1',ciphertext:'abc',sequenceNumber:1},'patrick-phone');
  fs.appendFileSync(path.join(c.varDir,'audit','audit.jsonl'),'{"tampered":true}\n');
  const h=c.health();
  assert.equal(h.status,'failed');
  assert.equal(h.audit.ok,false);
});