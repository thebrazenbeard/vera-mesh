import io, json, pathlib, tarfile, tempfile, unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
VERSION = "0.3.0-0005"

class PackageSourceTests(unittest.TestCase):
    def test_required_source_files_exist(self):
        required = [
            "package/INFO", "package/conf/privilege", "package/conf/resource",
            "package/scripts/start-stop-status", "package/scripts/postinst",
            "package/scripts/preupgrade", "package/scripts/postupgrade",
            "package/config/default-config.json", "package/share/SECURITY_BOUNDARY.txt",
            "package/bin/vera-relay", "src/audit.js", "src/runtime.js", "src/cli.js", "src/diagnostics.js",
            "tools/build_spk.py", "tools/validate_spk.py"
        ]
        for rel in required:
            self.assertTrue((ROOT / rel).is_file(), rel)

    def test_info_is_armada38x_dsm7_and_version_consistent(self):
        text = (ROOT / "package/INFO").read_text(encoding="utf-8")
        self.assertIn('arch="armada38x"', text)
        self.assertIn('os_min_ver="7.2-64570"', text)
        self.assertIn(f'version="{VERSION}"', text)
        self.assertIn('install_dep_packages="Node.js_v22"', text)

    def test_default_config_is_localhost_only(self):
        config = json.loads((ROOT / "package/config/default-config.json").read_text())
        self.assertEqual(config["bindAddress"], "127.0.0.1")
        self.assertEqual(config["port"], 17443)
        self.assertFalse(config["publicListener"])
        self.assertEqual(config["applicationAuthentication"], "ES256")

    def test_security_boundary_names_veramesh_and_no_public_funnel(self):
        text = (ROOT / "package/share/SECURITY_BOUNDARY.txt").read_text(encoding="utf-8")
        self.assertIn("VeraMesh", text)
        self.assertIn("Tailscale Serve", text)
        self.assertIn("Funnel is not enabled", text)
        self.assertIn(VERSION, text)

if __name__ == "__main__":
    unittest.main()
class LifecycleTests(unittest.TestCase):
    def test_lifecycle_scripts_prepare_audit_and_have_no_jq_dependency(self):
        names=["start-stop-status","postinst","postupgrade"]
        texts={name:(ROOT/"package/scripts"/name).read_text(encoding="utf-8") for name in names}
        for name,text in texts.items():
            self.assertNotIn("jq ",text,name)
            self.assertIn("audit",text,name)
        self.assertIn("/var/packages/Node.js_v22/target/usr/local/bin/node",texts["start-stop-status"])

    def test_upgrade_does_not_replace_existing_config(self):
        text=(ROOT/"package/scripts/postupgrade").read_text(encoding="utf-8")
        self.assertIn('if [ ! -f "$PKG_VAR/config.json" ]',text)

if __name__ == "__main__":
    unittest.main()
class StartupDiagnosticsTests(unittest.TestCase):
    def test_start_script_reports_failures_to_synology_temp_log(self):
        text=(ROOT/"package/scripts/start-stop-status").read_text(encoding="utf-8")
        self.assertIn("SYNOPKG_TEMP_LOGFILE",text)
        self.assertIn("config_preflight_failed",text)
        self.assertIn("runtime_exited_before_health",text)
        self.assertIn("startup_health_timeout",text)
        self.assertIn("report_tail",text)

class DeepStartupDiagnosticsTests(unittest.TestCase):
    def test_timeout_reports_runtime_state_and_verbose_health_probe(self):
        text=(ROOT/"package/scripts/start-stop-status").read_text(encoding="utf-8")
        self.assertIn("runtime-state",text)
        self.assertIn("health-probe",text)
        self.assertIn("/proc/$PID/status",text)

    def test_runtime_logs_child_lifecycle(self):
        text=(ROOT/"src/runtime.js").read_text(encoding="utf-8")
        for marker in ["runtime-start","server-spawn","server-exit","server-error"]:
            self.assertIn(marker,text)

class StartupRaceTests(unittest.TestCase):
    def test_startup_distinguishes_alive_from_owned(self):
        text=(ROOT/"package/scripts/start-stop-status").read_text(encoding="utf-8")
        self.assertIn("pid_alive()",text)
        self.assertIn('if ! pid_alive "$PID"; then',text)
        self.assertIn('if pid_is_ours "$PID" && health_ok "$NODE_BIN"; then',text)
        self.assertNotIn('if ! pid_is_ours "$PID"; then\n        report "runtime_exited_before_health',text)

if __name__ == "__main__":
    unittest.main()
