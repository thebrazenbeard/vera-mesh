'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { openRelayDatabase } = require('../src/db');
const { RelayRepository } = require('../src/repository');

function fixture() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'vera-relay-db-'));
  const db = openRelayDatabase({ dbPath:path.join(dir, 'relay.sqlite3') });
  return { dir, db, repo:new RelayRepository(db) };
}

function count(db, table) {
  return Number(db.prepare(`SELECT COUNT(*) AS n FROM ${table}`).get().n);
}

test('database enforces WAL FULL synchronous and foreign keys', () => {
  const { db } = fixture();
  assert.equal(db.prepare('PRAGMA journal_mode').get().journal_mode.toLowerCase(), 'wal');
  assert.equal(db.prepare('PRAGMA synchronous').get().synchronous, 2);
  assert.equal(db.prepare('PRAGMA foreign_keys').get().foreign_keys, 1);
  db.close();
});
test('pairing redemption is atomic with principal keys scopes and audit', () => {
  const { db, repo } = fixture();
  repo.createPairingSession({
    sessionId:'s1', tokenHash:'a'.repeat(64), role:'phone-client',
    scopes:['mailbox:submit','mailbox:fetch:self','receipt:create:self'],
    expiresAt:'2026-09-14T02:00:00.000Z'
  });
  db.exec("CREATE TRIGGER fail_pair_audit BEFORE INSERT ON audit_events WHEN NEW.event_type='pairing_redeemed' BEGIN SELECT RAISE(ABORT,'audit_fail'); END");
  assert.throws(() => repo.redeemPairing({
    sessionId:'s1', tokenHash:'a'.repeat(64), principalId:'phone:test',
    signingKeyId:'b'.repeat(64), signingSpki:'spki', hpkeKeyId:'c'.repeat(64),
    hpkePublicKey:'hpke', now:'2026-09-14T01:00:00.000Z'
  }), /audit_fail/);
  assert.equal(count(db,'principals'), 0);
  assert.equal(count(db,'signing_keys'), 0);
  assert.equal(count(db,'encryption_keys'), 0);
  assert.equal(count(db,'principal_scopes'), 0);
  assert.equal(db.prepare('SELECT consumed_at FROM pairing_sessions WHERE session_id=?').get('s1').consumed_at, null);
  db.close();
});
test('message acceptance and nonce consumption roll back together', () => {
  const { db, repo } = fixture();
  repo.ensurePrincipal({ principalId:'phone:test', role:'phone-client' });
  db.exec("CREATE TRIGGER fail_message_audit BEFORE INSERT ON audit_events WHEN NEW.event_type='message_accepted' BEGIN SELECT RAISE(ABORT,'audit_fail'); END");
  assert.throws(() => repo.acceptMessage({
    senderPrincipal:'phone:test', recipientPrincipal:'host:vera', messageId:'m1',
    envelopeSha256:'d'.repeat(64), streamId:'stream-1', messageSequence:1,
    envelopeJson:'{"sealed":true}', nonce:'nonce-1', now:'2026-09-14T01:00:00.000Z'
  }), /audit_fail/);
  assert.equal(count(db,'messages'), 0);
  assert.equal(count(db,'nonces'), 0);
  db.close();
});

test('same immutable message is idempotent and changed content conflicts', () => {
  const { db, repo } = fixture();
  repo.ensurePrincipal({ principalId:'phone:test', role:'phone-client' });
  const base={senderPrincipal:'phone:test',recipientPrincipal:'host:vera',messageId:'m1',
    envelopeSha256:'e'.repeat(64),streamId:'stream-1',messageSequence:1,
    envelopeJson:'{"sealed":true}',now:'2026-09-14T01:00:00.000Z'};
  const first=repo.acceptMessage({...base,nonce:'nonce-1'});
  const retry=repo.acceptMessage({...base,nonce:'nonce-2'});
  assert.equal(first.message_id, retry.message_id);
  assert.throws(() => repo.acceptMessage({...base,envelopeSha256:'f'.repeat(64),nonce:'nonce-3'}), /idempotency_conflict/);
  assert.equal(count(db,'messages'),1);
  db.close();
});
test('schema contains every minimum VeraMesh V1 mutable-state table', () => {
  const { db } = fixture();
  const names = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r=>r.name));
  for (const name of [
    'schema_metadata','relay_installation','principals','signing_keys','encryption_keys',
    'principal_scopes','pairing_sessions','nonces','messages','receipts','audit_events',
    'external_audit_checkpoints'
  ]) assert.ok(names.has(name), `missing table ${name}`);
  db.close();
});

test('relay installation identity is singleton state and audit checkpoints are append-only records', () => {
  const { db, repo } = fixture();
  repo.setRelayInstallation({ installationId:'relay-ds216', custodyKeyId:'a'.repeat(64), custodyKeyEpoch:1, createdAt:'2026-09-14T01:00:00.000Z' });
  assert.throws(() => repo.setRelayInstallation({ installationId:'other', custodyKeyId:'b'.repeat(64), custodyKeyEpoch:1, createdAt:'2026-09-14T01:01:00.000Z' }), /relay_installation_already_initialized/);
  repo.appendExternalAuditCheckpoint({ checkpointId:'cp1', auditHead:'c'.repeat(64), signerPrincipal:'host:vera', signature:'sig1', createdAt:'2026-09-14T01:02:00.000Z' });
  repo.appendExternalAuditCheckpoint({ checkpointId:'cp2', auditHead:'d'.repeat(64), signerPrincipal:'host:vera', signature:'sig2', createdAt:'2026-09-14T01:03:00.000Z' });
  assert.equal(count(db,'external_audit_checkpoints'), 2);
  assert.equal(db.prepare('SELECT installation_id FROM relay_installation WHERE singleton=1').get().installation_id, 'relay-ds216');
  db.close();
});