'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const {loadConfig}=require('../src/server');

function tempConfig(value){
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'vera-config-'));
  fs.writeFileSync(path.join(dir,'config.json'),JSON.stringify(value));
  return dir;
}
const base={bindAddress:'127.0.0.1',port:17443,publicListener:false,applicationAuthentication:'ES256',
  maxBodyBytes:65536,maxMessagesPerQueue:1000,maxQueueBytes:268435456,messageRetentionHours:24,
  deliveredGraceMinutes:60,replayWindowMinutes:10,cleanupIntervalSeconds:300};

test('config loader accepts secure configured limits',()=>{
  const c=loadConfig(tempConfig(base));
  assert.equal(c.maxMessagesPerQueue,1000); assert.equal(c.bindAddress,'127.0.0.1');
});
test('config loader rejects public binding or disabled application auth',()=>{
  assert.throws(()=>loadConfig(tempConfig({...base,bindAddress:'0.0.0.0'})),/invalid_bindAddress/);
  assert.throws(()=>loadConfig(tempConfig({...base,applicationAuthentication:'none'})),/invalid_applicationAuthentication/);
});
test('config loader keeps the DSM/Tailscale ingress port fixed at 17443',()=>{
  assert.throws(()=>loadConfig(tempConfig({...base,port:18443})),/invalid_port/);
});