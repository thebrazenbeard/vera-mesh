'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const { AuditLog }=require('../src/audit');

function temp(){return fs.mkdtempSync(path.join(os.tmpdir(),'vera-audit-'));}

test('audit records form a verifiable hash chain',()=>{
  const dir=temp(); const audit=new AuditLog(dir);
  audit.append('message_accepted',{actorId:'phone'});
  audit.append('message_acknowledged',{actorId:'host'});
  const result=audit.verify();
  assert.equal(result.ok,true); assert.equal(result.records,2);
});

test('audit verification detects tampering',()=>{
  const dir=temp(); const audit=new AuditLog(dir);
  audit.append('message_accepted',{actorId:'phone'});
  const file=path.join(dir,'audit','audit.jsonl');
  fs.appendFileSync(file,'{"tampered":true}\n');
  assert.equal(audit.verify().ok,false);
});
test('audit verification preserves chain across legacy rotated segments',()=>{
  const dir=temp(); const audit=new AuditLog(dir);
  audit.append('legacy_before_rotation',{relayInstanceId:'legacy-relay'});
  const auditDir=path.join(dir,'audit');
  fs.renameSync(path.join(auditDir,'audit.jsonl'),path.join(auditDir,'audit-1000.jsonl'));
  audit.append('current_after_rotation',{relayInstanceId:'legacy-relay'});
  const result=audit.verify();
  assert.equal(result.ok,true);
  assert.equal(result.records,2);
  assert.deepEqual(result.segments,['audit-1000.jsonl','audit.jsonl']);
});
