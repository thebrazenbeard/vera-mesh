import hashlib, importlib.util, pathlib, struct, subprocess, sys, tarfile, unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPK = ROOT / "dist/VeraRelay-0.3.0-0005-armada38x.spk"

def load_validator():
    spec=importlib.util.spec_from_file_location("validate_spk",ROOT/"tools/validate_spk.py")
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod); return mod

def png_size(path):
    data=path.read_bytes()
    if data[:8] != b'\x89PNG\r\n\x1a\n': raise AssertionError('not png')
    return struct.unpack('>II',data[16:24])

class BuildTests(unittest.TestCase):
    def build(self):
        subprocess.run([sys.executable,str(ROOT/'tools/build_spk.py')],cwd=ROOT,check=True,capture_output=True,text=True)
        return hashlib.sha256(SPK.read_bytes()).hexdigest()

    def test_build_is_deterministic_and_validator_accepts_artifact(self):
        first=self.build(); second=self.build()
        self.assertEqual(first,second)
        report=load_validator().validate(SPK)
        self.assertTrue(report['valid'],report['errors'])

    def test_package_icons_have_dsm7_dimensions(self):
        self.assertEqual(png_size(ROOT/'package/PACKAGE_ICON.PNG'),(64,64))
        self.assertEqual(png_size(ROOT/'package/PACKAGE_ICON_256.PNG'),(256,256))

    def test_outer_tar_metadata_is_deterministic_root_owned(self):
        self.build()
        with tarfile.open(SPK,'r:*') as tf:
            for member in tf.getmembers():
                self.assertEqual(member.mtime,0,member.name)
                self.assertEqual(member.uid,0,member.name)
                self.assertEqual(member.gid,0,member.name)

if __name__=='__main__': unittest.main()