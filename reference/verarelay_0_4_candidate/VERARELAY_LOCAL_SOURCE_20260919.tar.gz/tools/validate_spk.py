import gzip, hashlib, io, json, pathlib, re, sys, tarfile

VERSION = "0.3.0-0005"
ARCH = "armada38x"
EXPECTED_INNER = {
    "app/auth.js","app/audit.js","app/pairing.js","app/relay-core.js","app/server.js","app/runtime.js",
    "app/diagnostics.js","app/cli.js","config/default-config.json","bin/vera-relay","share/SECURITY_BOUNDARY.txt"
}
REQUIRED_OUTER = {
    "INFO","package.tgz","conf/privilege","conf/resource","PACKAGE_ICON.PNG","PACKAGE_ICON_256.PNG",
    "WIZARD_UIFILES/install_uifile","WIZARD_UIFILES/uninstall_uifile",
    "scripts/start-stop-status","scripts/preinst","scripts/postinst","scripts/preupgrade","scripts/postupgrade",
    "scripts/preuninst","scripts/postuninst"
}

def unique_members(tf):
    names=[m.name.rstrip('/') for m in tf.getmembers() if m.isfile()]
    dup=sorted({x for x in names if names.count(x)>1})
    return names,dup

def parse_info(text):
    result={}
    for line in text.splitlines():
        m=re.match(r'^([A-Za-z0-9_]+)="(.*)"$',line.strip())
        if m: result[m.group(1)]=m.group(2)
    return result

def validate(path):
    errors=[]; details={}
    raw=path.read_bytes(); details['sha256']=hashlib.sha256(raw).hexdigest(); details['bytes']=len(raw)
    with tarfile.open(path,'r:*') as outer:
        outer_names,dup=unique_members(outer); details['outer_files']=outer_names
        if dup: errors.append(f"duplicate outer members: {dup}")
        missing=sorted(REQUIRED_OUTER-set(outer_names))
        if missing: errors.append(f"missing outer members: {missing}")
        info=parse_info(outer.extractfile('INFO').read().decode())
        details['info']=info
        if info.get('version')!=VERSION: errors.append(f"INFO version {info.get('version')!r}")
        if info.get('arch')!=ARCH: errors.append(f"INFO arch {info.get('arch')!r}")
        for m in outer.getmembers():
            if m.isfile() and m.name.startswith('scripts/') and (m.mode & 0o777)!=0o755:
                errors.append(f"script not executable: {m.name} mode={oct(m.mode)}")
        package_bytes=outer.extractfile('package.tgz').read()
    with tarfile.open(fileobj=io.BytesIO(gzip.decompress(package_bytes)),mode='r:') as inner:
        inner_names,dup=unique_members(inner); details['inner_files']=inner_names
        if dup: errors.append(f"duplicate inner members: {dup}")
        if set(inner_names)!=EXPECTED_INNER: errors.append(f"inner members mismatch: {sorted(set(inner_names)^EXPECTED_INNER)}")
        members={m.name:m for m in inner.getmembers() if m.isfile()}
        if (members['bin/vera-relay'].mode & 0o777)!=0o755: errors.append('bin/vera-relay not executable')
        config=json.loads(inner.extractfile('config/default-config.json').read())
        if config.get('bindAddress')!='127.0.0.1' or config.get('publicListener') is not False: errors.append('listener boundary invalid')
        security=inner.extractfile('share/SECURITY_BOUNDARY.txt').read().decode()
        server=inner.extractfile('app/server.js').read().decode()
        cli=inner.extractfile('app/cli.js').read().decode()
        if VERSION not in security or VERSION not in server or VERSION not in cli: errors.append('version identity inconsistent')
        if '0.0.0.0' in server: errors.append('public bind literal found in server')
    details['valid']=not errors; details['errors']=errors
    return details
def main(argv):
    if len(argv)!=2:
        raise SystemExit('usage: validate_spk.py <spk>')
    path=pathlib.Path(argv[1]).resolve()
    report=validate(path)
    report_path=path.with_suffix(path.suffix+'.validation.json')
    report_path.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    print(json.dumps(report,indent=2,sort_keys=True))
    raise SystemExit(0 if report['valid'] else 1)

if __name__=='__main__':
    main(sys.argv)