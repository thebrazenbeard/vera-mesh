import gzip, hashlib, io, json, pathlib, tarfile

ROOT = pathlib.Path(__file__).resolve().parents[1]
VERSION = "0.3.0-0005"
ARCH = "armada38x"
DIST = ROOT / "dist"
OUT = DIST / f"VeraRelay-{VERSION}-{ARCH}.spk"
FIXED_MTIME = 0

PAYLOAD = {
    "app/auth.js": ROOT / "src/auth.js",
    "app/audit.js": ROOT / "src/audit.js",
    "app/pairing.js": ROOT / "src/pairing.js",
    "app/relay-core.js": ROOT / "src/relay-core.js",
    "app/server.js": ROOT / "src/server.js",
    "app/runtime.js": ROOT / "src/runtime.js",
    "app/diagnostics.js": ROOT / "src/diagnostics.js",
    "app/cli.js": ROOT / "src/cli.js",
    "config/default-config.json": ROOT / "package/config/default-config.json",
    "bin/vera-relay": ROOT / "package/bin/vera-relay",
    "share/SECURITY_BOUNDARY.txt": ROOT / "package/share/SECURITY_BOUNDARY.txt",
}

def tar_bytes(files, executable=()):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.GNU_FORMAT) as tf:
        dirs = sorted({str(pathlib.PurePosixPath(name).parent) for name in files if "/" in name} - {"."})
        for name in dirs:
            info = tarfile.TarInfo(name)
            info.type = tarfile.DIRTYPE
            info.mode = 0o755
            info.uid = info.gid = 0
            info.mtime = FIXED_MTIME
            info.uname = info.gname = "root"
            tf.addfile(info)
        for name in sorted(files):
            data = files[name] if isinstance(files[name], bytes) else pathlib.Path(files[name]).read_bytes()
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o755 if name in executable else 0o644
            info.uid = info.gid = 0
            info.mtime = FIXED_MTIME
            info.uname = info.gname = "root"
            tf.addfile(info, io.BytesIO(data))
    return raw.getvalue()

def gzip_bytes(data):
    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode="wb", mtime=FIXED_MTIME, filename="") as gz:
        gz.write(data)
    return out.getvalue()

def main():
    DIST.mkdir(exist_ok=True)
    package_tgz = gzip_bytes(tar_bytes(PAYLOAD, executable={"bin/vera-relay"}))
    outer = {
        "INFO": ROOT / "package/INFO",
        "package.tgz": package_tgz,
        "conf/privilege": ROOT / "package/conf/privilege",
        "conf/resource": ROOT / "package/conf/resource",
        "WIZARD_UIFILES/install_uifile": ROOT / "package/WIZARD_UIFILES/install_uifile",
        "WIZARD_UIFILES/uninstall_uifile": ROOT / "package/WIZARD_UIFILES/uninstall_uifile",
        "PACKAGE_ICON.PNG": ROOT / "package/PACKAGE_ICON.PNG",
        "PACKAGE_ICON_256.PNG": ROOT / "package/PACKAGE_ICON_256.PNG",
    }
    for script in sorted((ROOT / "package/scripts").iterdir()):
        if script.is_file():
            outer[f"scripts/{script.name}"] = script
    executable = {name for name in outer if name.startswith("scripts/")}
    OUT.write_bytes(tar_bytes(outer, executable=executable))
    digest = hashlib.sha256(OUT.read_bytes()).hexdigest()
    (DIST / f"{OUT.name}.sha256").write_text(f"{digest}  {OUT.name}\n", encoding="utf-8")
    print(json.dumps({"artifact": str(OUT), "sha256": digest, "bytes": OUT.stat().st_size}, indent=2))

if __name__ == "__main__":
    main()
