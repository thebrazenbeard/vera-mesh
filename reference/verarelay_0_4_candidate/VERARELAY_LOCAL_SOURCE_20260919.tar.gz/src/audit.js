'use strict';
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const { atomicWrite }=require('./auth');

function sha256(value){return crypto.createHash('sha256').update(value).digest('hex');}
class AuditLog{
  constructor(varDir){
    this.dir=path.join(varDir,'audit');
    this.file=path.join(this.dir,'audit.jsonl');
    this.headFile=path.join(this.dir,'HEAD');
    fs.mkdirSync(this.dir,{recursive:true,mode:0o700});
  }
  listSegments(){
    const rotated=fs.readdirSync(this.dir)
      .filter(name=>/^audit-\d+\.jsonl$/.test(name))
      .sort((a,b)=>Number(a.match(/\d+/)[0])-Number(b.match(/\d+/)[0]));
    if(fs.existsSync(this.file)) rotated.push('audit.jsonl');
    return rotated;
  }
  append(eventType,fields={}){
    const previousHash=fs.existsSync(this.headFile)?fs.readFileSync(this.headFile,'utf8').trim():'GENESIS';
    const base={eventId:crypto.randomUUID(),eventType,timestamp:new Date().toISOString(),previousHash,...fields};
    const eventHash=sha256(JSON.stringify(base));
    const record={...base,eventHash};
    fs.appendFileSync(this.file,`${JSON.stringify(record)}\n`,{mode:0o600});
    atomicWrite(this.headFile,`${eventHash}\n`);
    return record;
  }
  verify(){
    const segments=this.listSegments();
    let previous='GENESIS',records=0;
    for(const name of segments){
      const file=path.join(this.dir,name); let lineNumber=0;
      for(const line of fs.readFileSync(file,'utf8').split('\n').filter(Boolean)){
        lineNumber++; let record;
        try{record=JSON.parse(line);}catch{return {ok:false,records,file:name,line:lineNumber,reason:'invalid_json'};}
        const {eventHash,...base}=record;
        if(base.previousHash!==previous) return {ok:false,records,file:name,line:lineNumber,reason:'previous_hash_mismatch',expectedPrevious:previous,observedPrevious:base.previousHash};
        const calculated=sha256(JSON.stringify(base));
        if(calculated!==eventHash) return {ok:false,records,file:name,line:lineNumber,reason:'event_hash_mismatch',expectedEventHash:calculated,observedEventHash:eventHash};
        previous=eventHash; records++;
      }
    }
    const head=fs.existsSync(this.headFile)?fs.readFileSync(this.headFile,'utf8').trim():'GENESIS';
    if(head!==previous) return {ok:false,records,file:'HEAD',line:1,reason:'head_mismatch',expectedHead:previous,observedHead:head};
    return {ok:true,records,head,segments};
  }
}
module.exports={AuditLog};
