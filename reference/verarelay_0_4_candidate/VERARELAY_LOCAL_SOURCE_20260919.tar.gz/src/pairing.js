'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { atomicWrite, safeId } = require('./auth');

function tokenHash(token) { return crypto.createHash('sha256').update(token).digest(); }
function canonicalPairingProof({deviceId,nonce,token}) {
  return JSON.stringify({v:1,purpose:'vera-device-enrollment',deviceId:String(deviceId||''),nonce:String(nonce||''),tokenHash:tokenHash(String(token||'')).toString('base64url')});
}
function createPairingToken(varDir, now=Date.now(), ttlMs=10*60*1000) {
  const token=crypto.randomBytes(24).toString('base64url');
  const state={schemaVersion:1,tokenHash:tokenHash(token).toString('base64url'),createdAt:new Date(now).toISOString(),expiresAt:new Date(now+ttlMs).toISOString()};
  atomicWrite(path.join(varDir,'state','pairing.json'),`${JSON.stringify(state,null,2)}\n`);
  return {token,expiresAt:state.expiresAt};
}
function enrollDevice({varDir,token,deviceId,publicKeySpkiBase64Url,proofSignature,nonce,now=Date.now()}) {
  const stateFile=path.join(varDir,'state','pairing.json');
  if(!fs.existsSync(stateFile)) throw new Error('pairing_not_enabled');
  const state=JSON.parse(fs.readFileSync(stateFile,'utf8'));
  if(now>Date.parse(state.expiresAt)) throw new Error('pairing_expired');
  const observed=tokenHash(String(token||''));
  const expected=Buffer.from(state.tokenHash,'base64url');
  if(observed.length!==expected.length || !crypto.timingSafeEqual(observed,expected)) throw new Error('invalid_pairing_token');
  if(!safeId(deviceId)||!safeId(nonce)||typeof publicKeySpkiBase64Url!=='string'||typeof proofSignature!=='string') throw new Error('invalid_pairing_request');
  const spki=Buffer.from(publicKeySpkiBase64Url,'base64url');
  const derived=crypto.createHash('sha256').update(spki).digest('base64url');
  if(derived!==deviceId) throw new Error('device_identity_mismatch');
  const key=crypto.createPublicKey({key:spki,format:'der',type:'spki'});
  const proof=canonicalPairingProof({deviceId,nonce,token});
  if(!crypto.verify('sha256',Buffer.from(proof),key,Buffer.from(proofSignature,'base64url'))) throw new Error('invalid_pairing_proof');
  const record={schemaVersion:1,deviceId,status:'active',algorithm:'ES256',publicKeySpkiBase64Url,enrolledAt:new Date(now).toISOString()};
  atomicWrite(path.join(varDir,'devices',`${deviceId}.json`),`${JSON.stringify(record,null,2)}\n`);
  fs.unlinkSync(stateFile);
  return record;
}
module.exports={createPairingToken,enrollDevice,canonicalPairingProof};