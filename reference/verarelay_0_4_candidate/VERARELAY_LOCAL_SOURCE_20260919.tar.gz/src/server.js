'use strict';
const http=require('node:http');
const crypto=require('node:crypto');
const fs=require('node:fs');
const path=require('node:path');
const {RelayCore}=require('./relay-core');
const {verifySignedRequest,cleanupReplay}=require('./auth');
const {enrollDevice}=require('./pairing');

const VERSION='0.3.0-0005';
const DEFAULTS={bindAddress:'127.0.0.1',port:17443,publicListener:false,applicationAuthentication:'ES256',
  maxBodyBytes:65536,maxMessagesPerQueue:1000,maxQueueBytes:268435456,messageRetentionHours:24,
  deliveredGraceMinutes:60,replayWindowMinutes:10,cleanupIntervalSeconds:300};

function loadConfig(varDir){
  const file=path.join(varDir,'config.json');
  const value=fs.existsSync(file)?{...DEFAULTS,...JSON.parse(fs.readFileSync(file,'utf8'))}:{...DEFAULTS};
  if(value.bindAddress!=='127.0.0.1') throw new Error('invalid_bindAddress');
  if(value.port!==17443) throw new Error('invalid_port');
  if(value.publicListener!==false) throw new Error('invalid_publicListener');
  if(value.applicationAuthentication!=='ES256') throw new Error('invalid_applicationAuthentication');
  for(const key of ['port','maxBodyBytes','maxMessagesPerQueue','maxQueueBytes','messageRetentionHours','deliveredGraceMinutes','replayWindowMinutes','cleanupIntervalSeconds']){
    if(!Number.isFinite(value[key])||value[key]<=0) throw new Error(`invalid_${key}`);
  }
  return value;
}
function sendJson(res,status,value){
  const body=Buffer.from(JSON.stringify(value));
  res.writeHead(status,{'content-type':'application/json; charset=utf-8','content-length':body.length,
    'cache-control':'no-store','x-content-type-options':'nosniff','content-security-policy':"default-src 'none'"});
  res.end(body);
}
function readBody(req,maxBytes){
  return new Promise((resolve,reject)=>{const chunks=[];let bytes=0;
    req.on('data',chunk=>{bytes+=chunk.length;if(bytes>maxBytes){reject(Object.assign(new Error('body_too_large'),{status:413}));req.destroy();return;}chunks.push(chunk);});
    req.on('end',()=>resolve(Buffer.concat(chunks)));req.on('error',reject);});
}
function parseJson(buffer){if(!buffer.length)return{};try{return JSON.parse(buffer.toString('utf8'));}catch{throw Object.assign(new Error('invalid_json'),{status:400});}}
function authErrorStatus(message){if(message==='device_revoked'||message==='device_not_active')return 403;if(message==='replay_detected'||message==='sequence_not_monotonic')return 409;return 401;}
function authFrom(req,requestPath,body,varDir,replayWindowMinutes){
  const request={method:req.method,path:requestPath,timestamp:req.headers['x-vera-timestamp'],nonce:req.headers['x-vera-nonce'],
    sequence:Number(req.headers['x-vera-sequence']),bodyHash:crypto.createHash('sha256').update(body).digest('hex')};
  return verifySignedRequest({varDir,request,headers:{deviceId:req.headers['x-vera-device-id'],signature:req.headers['x-vera-signature']},replayWindowMs:replayWindowMinutes*60000});
}
function createRelayServer({varDir,version=VERSION}){
  const config=loadConfig(varDir);
  const core=new RelayCore({varDir,version,maxMessagesPerQueue:config.maxMessagesPerQueue,maxQueueBytes:config.maxQueueBytes,
    messageRetentionHours:config.messageRetentionHours,deliveredGraceMinutes:config.deliveredGraceMinutes});
  const server=http.createServer(async(req,res)=>{
    const url=new URL(req.url,'http://127.0.0.1');
    const requestPath=`${url.pathname}${url.search}`;
    try{
      if(req.method==='GET'&&url.pathname==='/health') return sendJson(res,200,core.health());
      if(req.method==='GET'&&url.pathname==='/v1/capabilities') return sendJson(res,200,core.capabilities());
      if(req.method==='POST'&&url.pathname==='/v1/pair'){
        const body=parseJson(await readBody(req,config.maxBodyBytes));
        try{
          const record=enrollDevice({varDir,token:body.token,deviceId:body.deviceId,publicKeySpkiBase64Url:body.publicKeySpkiBase64Url,
            proofSignature:body.proofSignature,nonce:body.nonce});
          core.audit.append('device_enrolled',{deviceIdHash:crypto.createHash('sha256').update(record.deviceId).digest('hex')});
          return sendJson(res,201,{deviceId:record.deviceId,status:record.status,algorithm:record.algorithm});
        }catch(error){const status=error.message==='invalid_pairing_token'?401:error.message==='pairing_expired'?410:400;return sendJson(res,status,{errorCode:error.message});}
      }
      const queue=url.pathname.match(/^\/v1\/queue\/(phone-to-host|host-to-phone)(?:\/([^/]+)\/ack)?$/);
      if(!queue) return sendJson(res,404,{errorCode:'not_found'});
      const bodyBuffer=await readBody(req,config.maxBodyBytes);
      let actor;
      try{actor=authFrom(req,requestPath,bodyBuffer,varDir,config.replayWindowMinutes);}
      catch(error){return sendJson(res,authErrorStatus(error.message),{errorCode:error.message});}
      const direction=queue[1],messageId=queue[2];
      if(req.method==='POST'&&!messageId){
        const result=core.enqueue(direction,parseJson(bodyBuffer),actor.deviceId);
        return sendJson(res,result.duplicate?200:202,{accepted:true,duplicate:result.duplicate,messageId:result.record.messageId,acknowledgementState:result.record.acknowledgementState});
      }
      if(req.method==='GET'&&!messageId){
        const after=Number(url.searchParams.get('afterSequence')||-1),limit=Number(url.searchParams.get('limit')||50);
        return sendJson(res,200,{messages:core.fetch(direction,after,limit)});
      }
      if(req.method==='POST'&&messageId){
        const record=core.acknowledge(direction,messageId,parseJson(bodyBuffer).state,actor.deviceId);
        return sendJson(res,200,{messageId:record.messageId,acknowledgementState:record.acknowledgementState});
      }
      return sendJson(res,405,{errorCode:'method_not_allowed'});
    }catch(error){return sendJson(res,error.status||500,{errorCode:error.message||'internal_error'});}
  });
  const timer=setInterval(()=>{try{core.cleanup();cleanupReplay(varDir,Date.now(),config.replayWindowMinutes*60000);}catch{}},Math.max(30,config.cleanupIntervalSeconds)*1000);
  timer.unref(); server.on('close',()=>clearInterval(timer)); server.veraConfig=config;
  return server;
}
if(require.main===module){
  const varDir=process.env.VERA_RELAY_VAR||'/var/packages/VeraRelay/var';
  const server=createRelayServer({varDir,version:VERSION});
  server.listen(server.veraConfig.port,server.veraConfig.bindAddress);
  const stop=()=>server.close(()=>process.exit(0));
  process.on('SIGTERM',stop);process.on('SIGINT',stop);
}
module.exports={createRelayServer,loadConfig,readBody,authFrom};