'use strict';

const SCHEMA_MIGRATIONS = [
  {
    version: 1,
    up(db) {
      db.exec(`
        CREATE TABLE relay_installation(
          singleton INTEGER PRIMARY KEY CHECK(singleton=1),
          installation_id TEXT NOT NULL UNIQUE,
          custody_key_id TEXT NOT NULL,
          custody_key_epoch INTEGER NOT NULL CHECK(custody_key_epoch>=1),
          created_at TEXT NOT NULL
        );
        CREATE TABLE principals(
          principal_id TEXT PRIMARY KEY,
          role TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'active',
          created_at TEXT NOT NULL
        );
        CREATE TABLE signing_keys(
          key_id TEXT PRIMARY KEY,
          principal_id TEXT NOT NULL REFERENCES principals(principal_id),
          spki TEXT NOT NULL,
          key_epoch INTEGER NOT NULL,
          state TEXT NOT NULL DEFAULT 'active'
        );
        CREATE TABLE encryption_keys(
          key_id TEXT PRIMARY KEY,
          principal_id TEXT NOT NULL REFERENCES principals(principal_id),
          public_key TEXT NOT NULL,
          key_epoch INTEGER NOT NULL,
          state TEXT NOT NULL DEFAULT 'active'
        );
        CREATE TABLE principal_scopes(
          principal_id TEXT NOT NULL REFERENCES principals(principal_id),
          scope TEXT NOT NULL,
          PRIMARY KEY(principal_id, scope)
        );
        CREATE TABLE pairing_sessions(
          session_id TEXT PRIMARY KEY,
          token_hash TEXT NOT NULL,
          enrollment_role TEXT NOT NULL,
          scopes_json TEXT NOT NULL,
          expires_at TEXT NOT NULL,
          consumed_at TEXT
        );
        CREATE TABLE nonces(
          principal_id TEXT NOT NULL REFERENCES principals(principal_id),
          nonce TEXT NOT NULL,
          consumed_at TEXT NOT NULL,
          PRIMARY KEY(principal_id, nonce)
        );
        CREATE TABLE messages(
          sender_principal TEXT NOT NULL REFERENCES principals(principal_id),
          message_id TEXT NOT NULL,
          recipient_principal TEXT NOT NULL,
          envelope_sha256 TEXT NOT NULL,
          stream_id TEXT NOT NULL,
          message_sequence INTEGER NOT NULL,
          envelope_json TEXT NOT NULL,
          accepted_at TEXT NOT NULL,
          PRIMARY KEY(sender_principal, message_id)
        );
        CREATE TABLE receipts(
          receipt_id TEXT PRIMARY KEY,
          sender_principal TEXT NOT NULL,
          message_id TEXT NOT NULL,
          receipt_type TEXT NOT NULL,
          signer_principal TEXT NOT NULL,
          receipt_json TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY(sender_principal, message_id) REFERENCES messages(sender_principal, message_id)
        );
        CREATE TABLE audit_events(
          audit_id INTEGER PRIMARY KEY AUTOINCREMENT,
          event_type TEXT NOT NULL,
          principal_id TEXT,
          subject_id TEXT,
          event_json TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE TABLE external_audit_checkpoints(
          checkpoint_id TEXT PRIMARY KEY,
          audit_head TEXT NOT NULL,
          signer_principal TEXT NOT NULL,
          signature TEXT NOT NULL,
          created_at TEXT NOT NULL
        );
      `);
    }
  }
];

module.exports = { SCHEMA_MIGRATIONS };
