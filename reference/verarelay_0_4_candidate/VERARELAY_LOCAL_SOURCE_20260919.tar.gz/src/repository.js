'use strict';

class RelayRepository {
  constructor(db) { this.db = db; }

  transaction(fn) {
    this.db.exec('BEGIN IMMEDIATE');
    try {
      const value = fn();
      this.db.exec('COMMIT');
      return value;
    } catch (error) {
      try { this.db.exec('ROLLBACK'); } catch {}
      throw error;
    }
  }

  ensurePrincipal({ principalId, role, now = new Date().toISOString() }) {
    this.db.prepare(`INSERT OR IGNORE INTO principals
      (principal_id, role, status, created_at) VALUES (?, ?, 'active', ?)`)
      .run(principalId, role, now);
    return this.db.prepare('SELECT * FROM principals WHERE principal_id=?').get(principalId);
  }

  setRelayInstallation({ installationId, custodyKeyId, custodyKeyEpoch, createdAt }) {
    const existing = this.db.prepare('SELECT * FROM relay_installation WHERE singleton=1').get();
    if (existing) throw new Error('relay_installation_already_initialized');
    this.db.prepare(`INSERT INTO relay_installation
      (singleton, installation_id, custody_key_id, custody_key_epoch, created_at)
      VALUES (1, ?, ?, ?, ?)`).run(installationId, custodyKeyId, custodyKeyEpoch, createdAt);
    return this.db.prepare('SELECT * FROM relay_installation WHERE singleton=1').get();
  }
  appendExternalAuditCheckpoint({ checkpointId, auditHead, signerPrincipal, signature, createdAt }) {
    this.db.prepare(`INSERT INTO external_audit_checkpoints
      (checkpoint_id, audit_head, signer_principal, signature, created_at)
      VALUES (?, ?, ?, ?, ?)`)
      .run(checkpointId, auditHead, signerPrincipal, signature, createdAt);
  }

  createPairingSession({ sessionId, tokenHash, role, scopes, expiresAt }) {
    this.db.prepare(`INSERT INTO pairing_sessions
      (session_id, token_hash, enrollment_role, scopes_json, expires_at, consumed_at)
      VALUES (?, ?, ?, ?, ?, NULL)`)
      .run(sessionId, tokenHash, role, JSON.stringify(scopes), expiresAt);
  }

  redeemPairing({ sessionId, tokenHash, principalId, signingKeyId, signingSpki,
    hpkeKeyId, hpkePublicKey, now }) {
    return this.transaction(() => {
      const session = this.db.prepare('SELECT * FROM pairing_sessions WHERE session_id=?').get(sessionId);
      if (!session || session.consumed_at) throw new Error('pairing_not_enabled');
      if (session.token_hash !== tokenHash) throw new Error('pairing_token_invalid');
      if (Date.parse(now) > Date.parse(session.expires_at)) throw new Error('pairing_expired');

      this.db.prepare(`INSERT INTO principals
        (principal_id, role, status, created_at) VALUES (?, ?, 'active', ?)`)
        .run(principalId, session.enrollment_role, now);
      this.db.prepare(`INSERT INTO signing_keys
        (key_id, principal_id, spki, key_epoch, state) VALUES (?, ?, ?, 1, 'active')`)
        .run(signingKeyId, principalId, signingSpki);
      this.db.prepare(`INSERT INTO encryption_keys
        (key_id, principal_id, public_key, key_epoch, state) VALUES (?, ?, ?, 1, 'active')`)
        .run(hpkeKeyId, principalId, hpkePublicKey);
      for (const scope of JSON.parse(session.scopes_json)) {
        this.db.prepare('INSERT INTO principal_scopes(principal_id, scope) VALUES (?, ?)')
          .run(principalId, scope);
      }
      this.db.prepare('UPDATE pairing_sessions SET consumed_at=? WHERE session_id=?')
        .run(now, sessionId);
      this.appendAudit('pairing_redeemed', principalId, sessionId,
        { role:session.enrollment_role }, now);
      return this.db.prepare('SELECT * FROM principals WHERE principal_id=?').get(principalId);
    });
  }

  acceptMessage({ senderPrincipal, recipientPrincipal, messageId, envelopeSha256,
    streamId, messageSequence, envelopeJson, nonce, now }) {
    return this.transaction(() => {
      this.db.prepare('INSERT INTO nonces(principal_id, nonce, consumed_at) VALUES (?, ?, ?)')
        .run(senderPrincipal, nonce, now);
      const existing = this.db.prepare(`SELECT * FROM messages
        WHERE sender_principal=? AND message_id=?`).get(senderPrincipal, messageId);
      if (existing) {
        if (existing.envelope_sha256 !== envelopeSha256 || existing.envelope_json !== envelopeJson)
          throw new Error('idempotency_conflict');
        return existing;
      }
      this.db.prepare(`INSERT INTO messages
        (sender_principal, message_id, recipient_principal, envelope_sha256,
         stream_id, message_sequence, envelope_json, accepted_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(senderPrincipal, messageId, recipientPrincipal, envelopeSha256,
          streamId, messageSequence, envelopeJson, now);
      this.appendAudit('message_accepted', senderPrincipal, messageId,
        { recipientPrincipal, envelopeSha256 }, now);
      return this.db.prepare(`SELECT * FROM messages
        WHERE sender_principal=? AND message_id=?`).get(senderPrincipal, messageId);
    });
  }

  appendAudit(eventType, principalId, subjectId, event, now) {
    this.db.prepare(`INSERT INTO audit_events
      (event_type, principal_id, subject_id, event_json, created_at)
      VALUES (?, ?, ?, ?, ?)`)
      .run(eventType, principalId, subjectId, JSON.stringify(event), now);
  }
}

module.exports = { RelayRepository };
