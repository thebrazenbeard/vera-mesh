'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');

const varDir = process.env.VERA_RELAY_VAR || '/var/packages/VeraRelay/var';
const serverPath = path.join(__dirname, 'server.js');
const nodeBin = process.execPath;
const stateDir = path.join(varDir, 'state');
const stateFile = path.join(stateDir, 'runtime.json');
const logFile = path.join(varDir, 'vera-relay.log');
fs.mkdirSync(stateDir, { recursive:true, mode:0o700 });

let child = null;
let stopping = false;
let restartTimes = [];

function log(message) {
  fs.appendFileSync(logFile, `${new Date().toISOString()} runtime ${message}\n`, { mode:0o600 });
}
function writeState(value) {
  const tmp = `${stateFile}.tmp.${process.pid}`;
  fs.writeFileSync(tmp, `${JSON.stringify({...value,runtimePid:process.pid,updatedAt:new Date().toISOString()},null,2)}\n`, { mode:0o600 });
  fs.renameSync(tmp, stateFile);
}

log(`runtime-start pid=${process.pid} node=${nodeBin} nodeVersion=${process.version} server=${serverPath} var=${varDir}`);
function launch() {
  const now = Date.now();
  restartTimes = restartTimes.filter(t => now - t < 60000);
  if (restartTimes.length >= 5) {
    writeState({status:'failed',terminal:true,reason:'restart_limit_reached'});
    log('restart-limit-reached');
    return;
  }
  restartTimes.push(now);
  child = spawn(nodeBin, [serverPath], { env:{...process.env,VERA_RELAY_VAR:varDir}, stdio:['ignore','pipe','pipe'] });
  child.stdout.on('data',d=>fs.appendFileSync(logFile,d));
  child.stderr.on('data',d=>fs.appendFileSync(logFile,d));
  child.on('spawn',()=>log(`server-spawn pid=${child.pid} attempt=${restartTimes.length}`));
  child.on('error',error=>{
    log(`server-error code=${error.code||''} message=${error.message}`);
    writeState({status:'spawn-error',terminal:false,code:error.code||null,message:error.message});
  });
  writeState({status:'running',terminal:false,serverPid:child.pid,restartCount:restartTimes.length});
  child.on('exit',(code,signal)=>{
    log(`server-exit pid=${child && child.pid ? child.pid : 'unknown'} code=${code} signal=${signal}`);
    writeState({status:'exited',terminal:false,code,signal,restartCount:restartTimes.length});
    child = null;
    if (!stopping) setTimeout(launch, 2000);
  });
}
function stop(signal) {
  if (stopping) return;
  stopping = true;
  log(`runtime-stop signal=${signal}`);
  writeState({status:'stopping',terminal:false,signal});
  if (child) child.kill('SIGTERM');
  setTimeout(()=>process.exit(0),12000).unref();
}
process.on('SIGTERM',()=>stop('SIGTERM'));
process.on('SIGINT',()=>stop('SIGINT'));
process.on('uncaughtException',error=>{
  try { log(`runtime-uncaught ${error.stack||error.message}`); } catch {}
  throw error;
});
launch();
