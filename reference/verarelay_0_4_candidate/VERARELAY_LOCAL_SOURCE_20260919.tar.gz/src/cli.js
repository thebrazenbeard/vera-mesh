'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');
const { createPairingToken } = require('./pairing');
const { diagnostics, tailscaleBinary } = require('./diagnostics');

const VERSION='0.3.0-0005';
const varDir=process.env.VERA_RELAY_VAR || '/var/packages/VeraRelay/var';

function listDevices() {
  const dir=path.join(varDir,'devices');
  if(!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter(x=>x.endsWith('.json')).sort().map(name=>JSON.parse(fs.readFileSync(path.join(dir,name),'utf8')));
}
function revokeDevice(deviceId) {
  const file=path.join(varDir,'devices',`${deviceId}.json`);
  if(!fs.existsSync(file)) throw new Error('device_not_found');
  const record=JSON.parse(fs.readFileSync(file,'utf8'));
  record.status='revoked'; record.revokedAt=new Date().toISOString();
  fs.writeFileSync(file,`${JSON.stringify(record,null,2)}\n`,{mode:0o600});
  return record;
}
function enableTailscaleServe() {
  const exe=tailscaleBinary();
  if(!exe) throw new Error('tailscale_not_installed');
  const r=spawnSync(exe,['serve','--bg','http://127.0.0.1:17443'],{encoding:'utf8'});
  if(r.status!==0) throw new Error(`tailscale_serve_failed:${(r.stderr||'').trim()}`);
  return {ok:true,stdout:(r.stdout||'').trim()};
}
function main(argv) {
  const cmd=argv[2];
  if(cmd==='pairing-start') return console.log(JSON.stringify(createPairingToken(varDir),null,2));
  if(cmd==='device-list') return console.log(JSON.stringify(listDevices(),null,2));
  if(cmd==='device-revoke') return console.log(JSON.stringify(revokeDevice(argv[3]),null,2));
  if(cmd==='diagnostics') return console.log(JSON.stringify(diagnostics(varDir,VERSION),null,2));
  if(cmd==='tailscale-enable') return console.log(JSON.stringify(enableTailscaleServe(),null,2));
  console.error('Usage: vera-relay {pairing-start|device-list|device-revoke <id>|diagnostics|tailscale-enable}');
  process.exitCode=2;
}
if(require.main===module) main(process.argv);
module.exports={listDevices,revokeDevice,enableTailscaleServe,main};