'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { spawnSync } = require('node:child_process');

function findExecutable(candidates) {
  for (const candidate of candidates) {
    if (candidate && fs.existsSync(candidate)) return candidate;
  }
  return null;
}
function runJson(exe,args) {
  if (!exe) return {available:false};
  const result = spawnSync(exe,args,{encoding:'utf8'});
  if (result.status !== 0) return {available:true,ok:false,status:result.status,stderr:(result.stderr||'').trim()};
  try { return {available:true,ok:true,data:JSON.parse(result.stdout)}; }
  catch { return {available:true,ok:true,text:(result.stdout||'').trim()}; }
}
function tailscaleBinary() {
  return findExecutable([
    '/var/packages/Tailscale/target/bin/tailscale',
    '/var/packages/Tailscale/target/usr/local/bin/tailscale',
    '/usr/local/bin/tailscale',
    '/usr/bin/tailscale'
  ]);
}
function transportDiagnostics() {
  const exe = tailscaleBinary();
  const status = runJson(exe,['status','--json']);
  const serve = runJson(exe,['serve','status','--json']);
  return {
    adapter:'tailscale',
    executable:exe,
    installed:Boolean(exe),
    tailnet:status,
    serve,
    requiredBackend:'http://127.0.0.1:17443',
    publicFunnelRequired:false
  };
}
function diagnostics(varDir,version) {
  const runtimeFile = path.join(varDir,'state','runtime.json');
  const devicesDir = path.join(varDir,'devices');
  return {
    package:'VeraRelay', version, protocolDomain:'VeraMesh', nodeRole:'relay',
    bindAddress:'127.0.0.1', port:17443, publicListener:false,
    applicationAuthentication:'ES256',
    runtime:fs.existsSync(runtimeFile)?JSON.parse(fs.readFileSync(runtimeFile,'utf8')):null,
    enrolledDevices:fs.existsSync(devicesDir)?fs.readdirSync(devicesDir).filter(x=>x.endsWith('.json')).length:0,
    transport:transportDiagnostics()
  };
}
module.exports={diagnostics,transportDiagnostics,tailscaleBinary,findExecutable};