'use strict';
const fs=require('node:fs');
const path=require('node:path');
const {atomicWrite,safeId,sha256}=require('./auth');
const {AuditLog}=require('./audit');

class RelayCore{
  constructor({varDir,version,maxMessagesPerQueue=1000,maxQueueBytes=268435456,messageRetentionHours=24,deliveredGraceMinutes=60}){
    this.varDir=varDir; this.version=version;
    this.maxMessagesPerQueue=maxMessagesPerQueue; this.maxQueueBytes=maxQueueBytes;
    this.messageRetentionHours=messageRetentionHours; this.deliveredGraceMinutes=deliveredGraceMinutes;
    this.queues={
      'phone-to-host':path.join(varDir,'queues','phone-to-host'),
      'host-to-phone':path.join(varDir,'queues','host-to-phone')
    };
    for(const dir of Object.values(this.queues)) fs.mkdirSync(dir,{recursive:true,mode:0o700});
    this.audit=new AuditLog(varDir);
  }
  capabilities(){
    return {protocolDomain:'VeraMesh',nodeRole:'relay',transportNeutral:true,version:this.version,
      queueDirections:Object.keys(this.queues),applicationAuthentication:'ES256',replayProtection:true,
      durableDelivery:true,capabilityAdvertisement:true,healthAdvertisement:true};
  }
  health(){
    const audit=this.audit.verify();
    return {status:audit.ok?'ok':'failed',version:this.version,bindAddress:'127.0.0.1',port:17443,publicListener:false,
      applicationAuthentication:'ES256',nodeRole:'relay',protocolDomain:'VeraMesh',audit};
  }
  queueFiles(direction){
    const dir=this.queues[direction]; if(!dir) throw new Error('invalid_direction');
    return fs.readdirSync(dir).filter(x=>x.endsWith('.json')).sort();
  }
  queueStats(direction){
    let count=0,bytes=0;
    for(const name of this.queueFiles(direction)){const st=fs.statSync(path.join(this.queues[direction],name));count++;bytes+=st.size;}
    return {count,bytes};
  }
  totalQueueBytes(){return Object.keys(this.queues).reduce((n,d)=>n+this.queueStats(d).bytes,0);}
  enqueue(direction,envelope,actorId,now=Date.now()){
    if(!this.queues[direction]) throw new Error('invalid_direction');
    if(!safeId(envelope.messageId)) throw new Error('invalid_message_id');
    if(typeof envelope.ciphertext!=='string'||!envelope.ciphertext) throw new Error('ciphertext_required');
    const file=path.join(this.queues[direction],`${envelope.messageId}.json`);
    if(fs.existsSync(file)) return {duplicate:true,record:JSON.parse(fs.readFileSync(file,'utf8'))};
    const record={schemaVersion:1,messageId:envelope.messageId,direction,senderId:actorId,
      recipientId:safeId(envelope.recipientId)?envelope.recipientId:null,
      sequenceNumber:Number.isSafeInteger(envelope.sequenceNumber)?envelope.sequenceNumber:null,
      createdAt:new Date(now).toISOString(),expiresAt:new Date(now+this.messageRetentionHours*3600000).toISOString(),
      ciphertext:envelope.ciphertext,payloadHash:sha256(envelope.ciphertext),acknowledgementState:'relay_received'};
    const encoded=`${JSON.stringify(record)}\n`; const stats=this.queueStats(direction);
    if(stats.count>=this.maxMessagesPerQueue||this.totalQueueBytes()+Buffer.byteLength(encoded)>this.maxQueueBytes) throw new Error('queue_full');
    atomicWrite(file,encoded); this.audit.append('message_accepted',{actorId,direction,messageIdHash:sha256(envelope.messageId)});
    return {duplicate:false,record};
  }
  fetch(direction,afterSequence=-1,limit=50){
    const out=[];
    for(const name of this.queueFiles(direction)){
      const record=JSON.parse(fs.readFileSync(path.join(this.queues[direction],name),'utf8'));
      if(record.sequenceNumber===null||record.sequenceNumber>afterSequence) out.push(record);
    }
    return out.sort((a,b)=>(a.sequenceNumber??Number.MAX_SAFE_INTEGER)-(b.sequenceNumber??Number.MAX_SAFE_INTEGER)).slice(0,Math.min(limit,100));
  }
  acknowledge(direction,messageId,state,actorId,now=Date.now()){
    if(!safeId(messageId)) throw new Error('invalid_message_id');
    if(!['recipient_delivered','recipient_processed','rejected'].includes(state)) throw new Error('invalid_ack_state');
    const file=path.join(this.queues[direction],`${messageId}.json`);
    if(!fs.existsSync(file)) throw new Error('message_not_found');
    const record=JSON.parse(fs.readFileSync(file,'utf8'));
    record.acknowledgementState=state; record.acknowledgedAt=new Date(now).toISOString(); record.acknowledgedBy=actorId;
    atomicWrite(file,`${JSON.stringify(record)}\n`);
    this.audit.append('message_acknowledged',{actorId,direction,messageIdHash:sha256(messageId),result:state});
    return record;
  }
  cleanup(now=Date.now()){
    let removed=0;
    for(const [direction,dir] of Object.entries(this.queues)){
      for(const name of this.queueFiles(direction)){
        const file=path.join(dir,name); let record;
        try{record=JSON.parse(fs.readFileSync(file,'utf8'));}catch{continue;}
        const expires=Date.parse(record.expiresAt);
        const ack=record.acknowledgedAt?Date.parse(record.acknowledgedAt):NaN;
        const deliveredExpired=Number.isFinite(ack)&&now-ack>this.deliveredGraceMinutes*60000;
        if((Number.isFinite(expires)&&now>expires)||deliveredExpired){
          fs.unlinkSync(file); removed++;
          this.audit.append('message_released',{direction,messageIdHash:sha256(record.messageId),reason:deliveredExpired?'ack_grace_elapsed':'expired'});
        }
      }
    }
    return {removed};
  }
}
module.exports={RelayCore};