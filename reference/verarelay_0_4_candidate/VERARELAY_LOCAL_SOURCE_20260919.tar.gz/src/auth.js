'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');

function safeId(value) {
  return typeof value === 'string' && /^[A-Za-z0-9._:-]{1,128}$/.test(value);
}
function sha256(value) { return crypto.createHash('sha256').update(value).digest('hex'); }
function canonicalRequest(r) {
  return JSON.stringify({
    v:1,
    method:String(r.method || '').toUpperCase(),
    path:String(r.path || ''),
    timestamp:String(r.timestamp || ''),
    nonce:String(r.nonce || ''),
    sequence:Number(r.sequence),
    bodyHash:String(r.bodyHash || '')
  });
}
function atomicWrite(file, data, mode=0o600) {
  fs.mkdirSync(path.dirname(file), { recursive:true, mode:0o700 });
  const tmp = `${file}.tmp.${process.pid}.${crypto.randomBytes(4).toString('hex')}`;
  const fd = fs.openSync(tmp, 'wx', mode);
  try { fs.writeFileSync(fd, data); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(tmp, file);
}
function readDevice(varDir, deviceId) {
  if (!safeId(deviceId)) throw new Error('invalid_device_id');
  const file = path.join(varDir, 'devices', `${deviceId}.json`);
  if (!fs.existsSync(file)) throw new Error('unknown_device');
  const record = JSON.parse(fs.readFileSync(file, 'utf8'));
  if (record.status !== 'active') throw new Error(record.status === 'revoked' ? 'device_revoked' : 'device_not_active');
  return record;
}
function verifySignedRequest({ varDir, request, headers, now=Date.now(), replayWindowMs=10*60*1000 }) {
  const deviceId = headers && headers.deviceId;
  const signature = headers && headers.signature;
  if (!safeId(deviceId) || typeof signature !== 'string') throw new Error('authentication_required');
  if (!safeId(request.nonce)) throw new Error('invalid_nonce');
  if (!Number.isSafeInteger(request.sequence) || request.sequence < 0) throw new Error('invalid_sequence');
  const time = Date.parse(request.timestamp);
  if (!Number.isFinite(time) || Math.abs(now - time) > replayWindowMs) throw new Error('clock_skew');
  const device = readDevice(varDir, deviceId);
  if (device.algorithm !== 'ES256' || typeof device.publicKeySpkiBase64Url !== 'string') throw new Error('unsupported_device_key');
  const spki = Buffer.from(device.publicKeySpkiBase64Url, 'base64url');
  const derivedDeviceId = crypto.createHash('sha256').update(spki).digest('base64url');
  if (derivedDeviceId !== deviceId || device.deviceId !== deviceId) throw new Error('device_identity_mismatch');
  const key = crypto.createPublicKey({ key:spki, format:'der', type:'spki' });
  const ok = crypto.verify('sha256', Buffer.from(canonicalRequest(request)), key, Buffer.from(signature, 'base64url'));
  if (!ok) throw new Error('invalid_signature');

  const replayDir = path.join(varDir, 'replay');
  fs.mkdirSync(replayDir, { recursive:true, mode:0o700 });
  const replayFile = path.join(replayDir, `${sha256(`${deviceId}:${request.nonce}`)}.json`);
  if (fs.existsSync(replayFile)) throw new Error('replay_detected');
  const stateDir = path.join(varDir, 'auth-state', deviceId);
  fs.mkdirSync(stateDir, { recursive:true, mode:0o700 });
  const seqFile = path.join(stateDir, 'sequence');
  const previous = fs.existsSync(seqFile) ? Number(fs.readFileSync(seqFile, 'utf8').trim()) : -1;
  if (!Number.isSafeInteger(previous)) throw new Error('corrupt_sequence_state');
  if (request.sequence <= previous) throw new Error('sequence_not_monotonic');
  let fd;
  try {
    fd = fs.openSync(replayFile, 'wx', 0o600);
    fs.writeFileSync(fd, `${JSON.stringify({ deviceId, firstSeenAt:new Date(now).toISOString() })}\n`);
    fs.fsyncSync(fd); fs.closeSync(fd); fd = undefined;
  } catch (error) {
    if (fd !== undefined) try { fs.closeSync(fd); } catch {}
    if (error.code === 'EEXIST') throw new Error('replay_detected');
    throw error;
  }
  atomicWrite(seqFile, `${request.sequence}\n`);
  return { deviceId, signatureVerified:true, sequence:request.sequence, algorithm:'ES256' };
}

function cleanupReplay(varDir, now=Date.now(), replayWindowMs=10*60*1000) {
  const replayDir=path.join(varDir,'replay');
  if(!fs.existsSync(replayDir)) return {removed:0};
  let removed=0;
  for(const name of fs.readdirSync(replayDir).filter(x=>x.endsWith('.json'))){
    const file=path.join(replayDir,name);
    try{
      const record=JSON.parse(fs.readFileSync(file,'utf8'));
      const firstSeen=Date.parse(record.firstSeenAt);
      if(!Number.isFinite(firstSeen)||now-firstSeen>replayWindowMs){fs.unlinkSync(file);removed++;}
    }catch{fs.unlinkSync(file);removed++;}
  }
  return {removed};
}

module.exports = { canonicalRequest, verifySignedRequest, cleanupReplay, safeId, sha256, atomicWrite };