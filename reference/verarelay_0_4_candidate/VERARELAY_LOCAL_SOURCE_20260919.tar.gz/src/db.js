'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const { SCHEMA_MIGRATIONS } = require('./migrations');

function openRelayDatabase({ dbPath, migrations = SCHEMA_MIGRATIONS }) {
  fs.mkdirSync(path.dirname(dbPath), { recursive:true, mode:0o700 });
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode=WAL');
  db.exec('PRAGMA synchronous=FULL');
  db.exec('PRAGMA foreign_keys=ON');
  db.exec(`CREATE TABLE IF NOT EXISTS schema_metadata(
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
  )`);

  const row = db.prepare('SELECT MAX(version) AS version FROM schema_metadata').get();
  let current = Number(row.version || 0);
  for (const migration of migrations.slice().sort((a,b)=>a.version-b.version)) {
    if (migration.version <= current) continue;
    db.exec('BEGIN IMMEDIATE');    try {
      migration.up(db);
      db.prepare('INSERT INTO schema_metadata(version, applied_at) VALUES (?, ?)')
        .run(migration.version, new Date().toISOString());
      db.exec('COMMIT');
      current = migration.version;
    } catch (error) {
      try { db.exec('ROLLBACK'); } catch {}
      try { db.close(); } catch {}
      const wrapped = new Error(`migration_failed:${migration.version}:${error.message}`);
      wrapped.cause = error;
      throw wrapped;
    }
  }
  return db;
}

module.exports = { openRelayDatabase };
